# IDE Theme

[![code style: prettier](https://img.shields.io/badge/code_style-prettier-ff69b4.svg?style=flat-square)](https://github.com/prettier/prettier)


所有 token 列表和描述请见 [链接](https://yuque.antfin-inc.com/ide-framework/ide-token)
