// ### simple function
int cool_function(int i){
//  ^
	return i*2;
}
