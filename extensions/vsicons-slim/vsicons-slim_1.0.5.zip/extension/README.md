# vscode-icons-slim

> forked by `Kaitian`

Forked from https://github.com/vscode-icons/vscode-icons

移除的功能:
* 配置 preset 的能力
* extension.js 全部移除
